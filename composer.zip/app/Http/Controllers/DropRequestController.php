<?php

namespace App\Http\Controllers;

use App\Models\DropRequest;
use Illuminate\Http\Request;

class DropRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DropRequest  $dropRequest
     * @return \Illuminate\Http\Response
     */
    public function show(DropRequest $dropRequest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DropRequest  $dropRequest
     * @return \Illuminate\Http\Response
     */
    public function edit(DropRequest $dropRequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DropRequest  $dropRequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DropRequest $dropRequest)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DropRequest  $dropRequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(DropRequest $dropRequest)
    {
        //
    }
}
