declare namespace _default {
    const LEFT: string;
    const UP: string;
    const RIGHT: string;
    const DOWN: string;
}
export default _default;
//# sourceMappingURL=Key.d.ts.map